
const macchar = document.getElementById('macchar');
const startBtn = document.getElementById('startBtn');
const restartBtn = document.getElementById('restartBtn');
const scoreDisplay = document.getElementById('score');

let gravity = 2;
let isGameRunning = false;
let score = 0;
let velocity = 0;
let gameInterval;

function flap() {
  velocity = -20;
  new Audio('assets/flap.wav').play();
}

function startGame() {
  startBtn.style.display = 'none';
  restartBtn.style.display = 'none';
  isGameRunning = true;
  score = 0;
  macchar.style.top = '100px';
  velocity = 0;

  document.addEventListener('click', flap);

  gameInterval = setInterval(() => {
    const top = parseInt(getComputedStyle(macchar).top);
    velocity += gravity;
    macchar.style.top = `${top + velocity}px`;

    // Game Over condition
    if (top + velocity > window.innerHeight || top < 0) {
      endGame();
    }

    score++;
    scoreDisplay.textContent = 'Score: ' + score;
  }, 50);
}

function endGame() {
  clearInterval(gameInterval);
  isGameRunning = false;
  new Audio('assets/hit.wav').play();
  restartBtn.style.display = 'block';
  document.removeEventListener('click', flap);
}

startBtn.onclick = startGame;
restartBtn.onclick = startGame;
